There is a customer who came to me with a problem to have a custom linux 
command for his operations. My task is to understand the problem and create a linux 
command via bash script as per the instructions. 
Command name - internsctl 
Command version - v0.1.0
